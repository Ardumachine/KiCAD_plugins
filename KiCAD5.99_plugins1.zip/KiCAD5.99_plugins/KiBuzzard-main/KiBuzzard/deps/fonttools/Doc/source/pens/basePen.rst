#######
basePen
#######

.. automodule:: fontTools.pens.basePen
   :members:
   :undoc-members:
