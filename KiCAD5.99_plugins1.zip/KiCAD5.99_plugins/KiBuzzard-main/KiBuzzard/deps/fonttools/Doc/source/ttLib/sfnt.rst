####
sfnt
####

.. automodule:: fontTools.ttLib.sfnt
   :members:
   :undoc-members:
