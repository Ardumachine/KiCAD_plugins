##############
interpolatable
##############

.. automodule:: fontTools.varLib.interpolatable
   :members:
   :undoc-members:
