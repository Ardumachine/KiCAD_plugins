############
recordingPen
############

.. automodule:: fontTools.pens.recordingPen
   :members:
   :undoc-members:
