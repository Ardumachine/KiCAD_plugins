######
subset
######

.. automodule:: fontTools.subset
   :members:
   :undoc-members:
