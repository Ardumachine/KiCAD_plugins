###############
t2CharStringPen
###############

.. automodule:: fontTools.pens.t2CharStringPen
   :members:
   :undoc-members:
