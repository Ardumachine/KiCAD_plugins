######
cffLib
######

.. automodule:: fontTools.cffLib
   :members:
   :undoc-members:
