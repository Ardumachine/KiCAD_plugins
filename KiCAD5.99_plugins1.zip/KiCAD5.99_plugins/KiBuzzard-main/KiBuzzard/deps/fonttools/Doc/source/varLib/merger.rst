######
merger
######

.. automodule:: fontTools.varLib.merger
   :members:
   :undoc-members:
